// BL-30 (Bloque 1A) — Prueba de ESPECIFICACIÓN para el hallazgo R-03 / BL-04
// ("El PDF siempre muestra 'USD'", docs/velarix/auditoria/04-*, fUSD en
// src/lib/pdf-generator.ts:85-86, literal "USD" en pdf-generator.ts:433).
//
// Comportamiento correcto esperado (especificación, NO el actual): el PDF
// no debe imprimir la etiqueta de moneda "USD" de forma incondicional — hoy
// lo hace siempre, sin que `FinancialInputs`/`AnalysisResult` tengan ningún
// campo de moneda que lo justifique (confirmado: financial-engine.ts:97-123
// no declara `currency`). Para un negocio cuyo mercado principal son
// empresas colombianas (Negocio_Velarix_v4.1.md), un informe que nunca dice
// "USD" ni permite otra moneda es, en el mejor caso, ambiguo, y en el peor,
// incorrecto por ~4080x si el valor real está en COP (ver BL-02/BL-03).
//
// Esta prueba NO modifica src/lib/pdf-generator.ts. En vez de exportar las
// funciones internas (fUSD, etc.) — lo que constituiría el tipo de "refactor
// o modificación de comportamiento" que el Bloque 1A tiene prohibido
// improvisar — se usa un mock de las dependencias de terceros (`jspdf`,
// `jspdf-autotable`) para capturar cada cadena de texto que `generatePDF`
// intenta dibujar, y se verifica sobre esa captura. Mockear una librería de
// terceros en una prueba es una técnica estándar de testing, no un cambio al
// módulo bajo prueba.
//
// Resultado esperado de esta prueba: DEBE FALLAR contra el código actual
// (se usa `test.fails()` para mantener en verde el comando de pruebas
// general, tal como exige el cierre de Bloque 1A). Debe pasar únicamente
// después de que Bloque 1B corrija R-03 con una moneda paramétrica real.

import { describe, test, expect, vi, beforeEach } from "vitest";
import type { AnalysisResult, FinancialInputs } from "./financial-engine";

const capturedTexts: string[] = [];
const capturedTableCells: string[] = [];

vi.mock("jspdf", () => {
  class FakeJsPDF {
    lastAutoTable: { finalY: number } | undefined;
    internal = { getNumberOfPages: () => 1 };

    constructor(_opts?: unknown) {}

    setFillColor(..._args: unknown[]) { return this; }
    setDrawColor(..._args: unknown[]) { return this; }
    setLineWidth(..._args: unknown[]) { return this; }
    setFont(..._args: unknown[]) { return this; }
    setFontSize(..._args: unknown[]) { return this; }
    setTextColor(..._args: unknown[]) { return this; }
    rect(..._args: unknown[]) { return this; }
    roundedRect(..._args: unknown[]) { return this; }
    line(..._args: unknown[]) { return this; }
    addPage() { return this; }
    setPage(_n: number) { return this; }
    splitTextToSize(text: string, _maxW: number) { return [text]; }
    text(value: string | string[], _x?: number, _y?: number, _opts?: unknown) {
      if (Array.isArray(value)) capturedTexts.push(...value);
      else capturedTexts.push(value);
      return this;
    }
    save(_fileName: string) { /* no-op: no descarga real en la prueba */ }
  }
  return { default: FakeJsPDF };
});

vi.mock("jspdf-autotable", () => {
  return {
    default: (doc: { lastAutoTable?: { finalY: number } }, options: { head?: unknown[][]; body?: unknown[][] }) => {
      const flatten = (rows?: unknown[][]) =>
        (rows || []).flat().map((c) => String(c));
      capturedTableCells.push(...flatten(options.head));
      capturedTableCells.push(...flatten(options.body));
      doc.lastAutoTable = { finalY: 100 };
    },
  };
});

describe("BL-30 — especificación: pdf-generator no debe imprimir 'USD' sin una moneda real que lo respalde", () => {
  beforeEach(() => {
    capturedTexts.length = 0;
    capturedTableCells.length = 0;
  });

  test.fails("el PDF de una empresa colombiana no debería contener la etiqueta fija 'USD' (falla hoy: R-03 / BL-04)", async () => {
    const { generatePDF } = await import("./pdf-generator");
    const { DEFAULT_INPUTS, runAnalysis } = await import("./financial-engine");

    const inputs: FinancialInputs = {
      ...DEFAULT_INPUTS,
      companyName: "Empresa Colombiana de Prueba S.A.S.",
      sector: "Retail / Comercio",
    };
    const result: AnalysisResult = runAnalysis(inputs);

    await generatePDF(result, inputs, "ejecutivo");

    const allText = [...capturedTexts, ...capturedTableCells];
    const containsHardcodedUSD = allText.some((t) => /\bUSD\b/.test(t));

    // Especificación: ningún texto del informe debería forzar "USD" sin que
    // exista un campo de moneda real que lo determine.
    expect(containsHardcodedUSD).toBe(false);
  });
});
