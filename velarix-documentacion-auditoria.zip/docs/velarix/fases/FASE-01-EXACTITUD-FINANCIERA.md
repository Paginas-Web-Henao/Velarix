# Fase 01 — Exactitud Financiera

> **Actualizado 2026-07-23** tras la decisión de arquitectura `D-06`
> (`plan/REGISTRO-DE-DECISIONES.md`): el pipeline del servidor queda
> declarado como motor de cálculo canónico. Esta fase se divide en cuatro
> bloques internos secuenciales/parcialmente paralelos: **1A** (fuente
> única de verdad), **1B** (corrección financiera), **1C** (casos dorados
> y trazabilidad), **1D** (controles de acceso P0 del flujo intervenido).
> Ningún bloque se implementa todavía — esta actualización es solo
> documental.

## Estado

Pendiente de implementación. Decisión de arquitectura ya tomada (D-06).
No autorizada para implementación de código — requiere autorización
explícita adicional del fundador para empezar 1A.

## Objetivo

`Negocio_Velarix_v4.1.md` §18: "Impedir resultados incorrectos."

## Justificación de negocio

El mayor riesgo del negocio (§10.1) "no es una caída del sitio. Es
entregar un resultado convincente pero equivocado." La auditoría (Fase 0)
confirmó un split-brain arquitectónico y 4 bugs financieros críticos con
evidencia exacta. D-06 resuelve la ambigüedad de cuál motor corregir;
esta fase ejecuta esa decisión sin saltarse la disciplina de pruebas que
el propio negocio exige (§10.2, §10.4).

## Dependencias entre los cuatro bloques

```
1A (fuente única de verdad)
  │  — establece qué motor es la entrada de datos, qué tablas persisten
  │    el resultado, y las pruebas de caracterización de referencia
  ▼
1B (corrección financiera)
  │  — corrige los bugs DENTRO del motor ya declarado canónico por 1A;
  │    no tiene sentido corregir bugs en un motor que 1A podría no
  │    conectar todavía al flujo real
  ▼
1C (casos dorados y trazabilidad)
     — prueba y traza el resultado YA corregido por 1B; construir casos
       dorados antes de corregir los bugs conocidos sería documentar un
       comportamiento que se sabe incorrecto

1D (controles de acceso P0 del flujo)
     — en paralelo a 1A/1B/1C. No depende de ellas ni ellas de 1D, pero
       comparte archivos con 1A (ejecutar-calculo, continuar-tras-revision)
       — coordinar el orden de commits para no pisarse
```

**1D no bloquea a 1A/1B/1C ni viceversa** — pueden avanzar en paralelo.
Sí se recomienda que quien toque `ejecutar-calculo`/`continuar-tras-revision`
en 1A (para reconectar el flujo) y quien lo toque en 1D (para cerrar el
acceso) coordinen para no generar conflictos de merge innecesarios.

---

## Bloque 1A — Fuente única de verdad

### Alcance

- Inventario exacto de ambos motores (`ejecutar-calculo` vs.
  `financial-engine.ts`): entradas, fórmulas, salidas, consumidores de
  cada uno, en una tabla comparativa explícita.
- Declarar formalmente el motor del servidor como canónico en el código
  (no solo en documentación) — sin implementar todavía, esto se ejecuta
  en la fase real.
- Impedir que el PDF recalcule cifras — reconectar
  `Dashboard.tsx::handleDownloadPDF` para leer `analyses.calculation_result`
  en vez de volver a ejecutar `runAnalysis()`.
- Conectar `generate-narrative` (hoy huérfana, BL-20) al flujo real de
  `run-analysis-pipeline`, para que narrativa y PDF usen el mismo
  `calculation_result`.
- Definir estados de persistencia y aprobación del análisis (qué
  significa "calculado" vs. "aprobado para entrega" — hoy `informe_generado`
  se alcanza sin narrativa ni aprobación real, ver `auditoria/04`).
- Estrategia de transición sin eliminar prematuramente el motor del
  cliente (ver D-06, "Estrategia de transición").
- Pruebas de caracterización: registrar qué produce hoy
  `financial-engine.ts` para un conjunto de casos, antes de tocar nada,
  para poder comparar después.
- Corregir BL-06 (`run-analysis-pipeline` no aborta ante falla de
  `map-accounts`) como parte de asegurar la integridad del pipeline que
  se está declarando canónico.

### Hallazgos que resuelve

BL-01 (implementación de la decisión D-06 ya tomada), BL-06, BL-20. Ver
`plan/BACKLOG-CLASIFICADO.md`.

### Condiciones de entrada

- [x] D-06 registrada y confirmada por el fundador.
- [ ] Autorización explícita para iniciar implementación (pendiente).

### Archivos o componentes potencialmente afectados

`supabase/functions/run-analysis-pipeline/index.ts`,
`supabase/functions/ejecutar-calculo/index.ts`,
`supabase/functions/generate-narrative/index.ts`,
`src/pages/Dashboard.tsx`, `src/lib/pdf-generator.ts`,
`src/lib/financial-engine.ts` (se acota su alcance de uso, no se borra),
`src/lib/api-client.ts` (los wrappers huérfanos `generateNarrative`/
`storeCalculationResults` pasan a tener un caller real o se retiran si
1A decide otro mecanismo de conexión).

### Cambios de base de datos potenciales

Posible campo/estado nuevo para distinguir "calculado" de "aprobado para
entrega" en `analyses.status` o tabla relacionada (aditivo). Decidir si
`calculation_results` (tabla huérfana) se retira formalmente en favor de
la columna `analyses.calculation_result`, o viceversa — es la
consolidación de esquema que el hallazgo transversal de
`auditoria/08-INFRAESTRUCTURA-E-INTEGRACIONES.md` señaló.

### Riesgos

Ver R-04 en `plan/MATRIZ-DE-RIESGOS.md`. Riesgo adicional: reconectar el
PDF al resultado servidor puede exponer, por primera vez de forma visible
al usuario, el bug latente (B) de `ejecutar-calculo` — por eso 1B debe
completarse (al menos en lo que toca a ese bug) antes de considerar 1A
completamente cerrado en producción, aunque puedan desarrollarse en
paralelo.

### Pruebas obligatorias

- Pruebas de caracterización del motor cliente (snapshot de resultados
  actuales para un set de casos, antes de cualquier cambio).
- Prueba de que el PDF, tras el cambio, lee `calculation_result` y no
  vuelve a calcular.
- Prueba de que `generate-narrative` se ejecuta como parte del pipeline
  real y su resultado llega al PDF.
- Simulación de fallo de `map-accounts` (BL-06) que confirme que el
  pipeline se detiene correctamente.

### Criterios de aceptación

- Existe una tabla comparativa documentada de ambos motores.
- El PDF y la narrativa consumen el mismo `calculation_result`.
- El motor del cliente queda acotado exclusivamente a los 4 usos
  permitidos por D-06.
- Pruebas de caracterización existen y están versionadas antes de tocar
  el motor del servidor en 1B.

### Plan de rollback

Mantener el código del motor del cliente intacto (no se borra en este
bloque) — si la reconexión del PDF al servidor falla, se puede revertir
el cambio de `Dashboard.tsx` a su comportamiento anterior sin perder
ninguna capacidad, mientras se corrige el problema.

### Condiciones de detención

Si las pruebas de caracterización muestran que el motor del servidor
(antes de 1B) produce resultados muy distintos a los del cliente sin una
causa clara, detener y escalar al revisor financiero externo antes de
continuar — puede ser síntoma de un bug adicional no descubierto en la
auditoría original.

---

## Bloque 1B — Corrección financiera

### Alcance

Corregir, dentro del motor ya declarado canónico por 1A:

- BL-02 — Consolidación de subcuentas (`.find()` → suma).
- BL-03 — Conversión de moneda (persistir `moneda_documento`/`factor_escala`).
- BL-04 — Formato y etiqueta de moneda en PDF (`formatMoneda` paramétrica).
- BL-05 — Campo de deuda mal nombrado en `ejecutar-calculo`
  (`financial_debt_total`).
- BL-17 — Constantes duplicadas (TRM, Rf, ERP, datasets sectoriales) —
  consolidar a una fuente real y conectar `ejecutar-calculo` a
  `external_snapshots` corrigiendo el mismatch slug/label (hallazgo A).
- ROE/ROA (parte de R-04 en `plan/MATRIZ-DE-RIESGOS.md`) — usar
  `net_income` real donde exista, y agregar clamps de sanidad.
- Signos, unidades y redondeos — revisión puntual de
  `detectarConvencionSignos`/`detectarEscala` (`auditoria/04`) para
  confirmar que no queda ninguna doble aplicación tras los cambios de 1A.
- Fórmulas duplicadas — una vez 1A conecta todo al motor servidor, retirar
  o marcar explícitamente como solo-estimador el código de
  `financial-engine.ts` que quedaría redundante para el flujo profesional.

### Hallazgos que resuelve

BL-02, BL-03, BL-04, BL-05, BL-17. Ver `plan/BACKLOG-CLASIFICADO.md`.

### Condiciones de entrada

- [ ] 1A completado: motor servidor conectado a PDF/narrativa, pruebas de
      caracterización existentes.

### Archivos o componentes potencialmente afectados

`supabase/functions/build-structured-input/index.ts`,
`supabase/functions/validate-analysis/index.ts`,
`supabase/functions/continuar-tras-revision/index.ts`,
`supabase/functions/ejecutar-calculo/index.ts`,
`supabase/functions/parse-document/index.ts`,
`supabase/functions/update-snapshots/index.ts`,
`src/lib/pdf-generator.ts`, `src/data/velarix-datos-2026.ts`.

### Cambios de base de datos potenciales

Posible ajuste de la clave `sector` en `external_snapshots` (slug vs.
label) para BL-17 — preferir corregir el código de consulta antes que los
datos ya sembrados, si es posible.

### Riesgos

Ver R-01, R-02, R-03, R-05 en `plan/MATRIZ-DE-RIESGOS.md`.

### Pruebas obligatorias

- Caso de regresión de consolidación de subcuentas (Caja+Bancos+CDT=cash).
- Caso de regresión de conversión de moneda (Excel en USD → análisis en
  COP → cifras convertidas correctamente).
- Verificación de que ningún PDF en COP muestra "USD".
- Caso de regresión de deuda/WACC con empresa apalancada.
- Caso de regresión de ROE/ROA con datos reales vs. sintéticos, con clamp
  de sanidad activo.

### Criterios de aceptación

Cada bug de la lista anterior tiene su caso de regresión pasando, sobre
el motor ya declarado canónico por 1A — no sobre el motor descartado.

### Plan de rollback

Cada corrección en un commit separado y revertible. Ninguna migración
destructiva.

### Condiciones de detención

Si un caso de regresión revela que la corrección de un bug rompe otro
cálculo no documentado en la auditoría original, detener esa corrección
específica y escalar al revisor financiero externo.

---

## Bloque 1C — Casos dorados y trazabilidad

### Alcance

- BL-14 — Casos dorados y pruebas de regresión del motor financiero
  (formalizar como suite automatizada los casos ya usados en 1B, más
  casos adicionales con datos conocidos).
- Comparación con Excel independiente para al menos un caso real o
  realista (§10.2 del negocio).
- BL-15 — Trazabilidad mínima documento→cifra, extendida hasta el PDF
  (no solo hasta `structured_inputs`, como se había acotado antes de D-06
  — ahora que el PDF consume el resultado servidor, la trazabilidad debe
  llegar hasta ahí).
- Versionado de fórmulas y de fuentes de datos (constantes macro/
  sectoriales, ya consolidadas en 1B).

### Hallazgos que resuelve

BL-14, BL-15. Ver `plan/BACKLOG-CLASIFICADO.md` y
`plan/MATRIZ-DE-TRAZABILIDAD.md`.

### Condiciones de entrada

- [ ] 1B completado: los bugs conocidos ya no están presentes en el motor
      canónico (no tiene sentido crear casos dorados que documenten un
      comportamiento que se sabe incorrecto).

### Archivos o componentes potencialmente afectados

Nuevos archivos de prueba (`supabase/functions/**/*.test.ts` o
equivalente, `src/test/*` para lo que aplique al cliente), posible campo
nuevo de trazabilidad en `structured_inputs`/`calculation_results`
(aditivo).

### Cambios de base de datos potenciales

Campo(s) de trazabilidad (`document_id`/`mapping_id`/`source_row_ids` o
similar) en `structured_inputs` y `calculation_results` — aditivo.

### Riesgos

Ver R-13 en `plan/MATRIZ-DE-RIESGOS.md`.

### Pruebas obligatorias

Toda la suite de casos dorados debe ejecutarse en CI o localmente antes
de cualquier cambio futuro al motor de cálculo.

### Criterios de aceptación

`Negocio_Velarix_v4.1.md` §18, Fase 1: "casos dorados aprobados,
resultados reproducibles y revisión externa documentada." Se puede
responder "¿de qué fila/documento salió esta cifra del PDF?" sin
reconstrucción manual.

### Plan de rollback

No aplica en sentido destructivo — son pruebas y campos aditivos.

### Condiciones de detención

Si el revisor financiero externo no aprueba los casos dorados, no se
cierra este bloque ni la fase completa, aunque el código ya esté escrito.

---

## Bloque 1D — Controles de acceso P0 del flujo intervenido

### Alcance

Únicamente las vulnerabilidades críticas del pipeline que 1A/1B/1C van a
modificar — **no** es la auditoría completa de seguridad (eso sigue en
Fase 02):

- BL-07 — Ownership en `ejecutar-calculo`.
- BL-08 — Ownership/autenticación en `continuar-tras-revision`.
- Recorte de BL-09 — control real de rol suficiente para impedir que un
  cliente apruebe su propia revisión (no el sistema completo de roles y
  permisos por asignación, que sigue siendo alcance de Fase 02).
- Pruebas negativas de acceso cruzado (invocación con `analysis_id`
  ajeno).
- Registro en `audit_events` de las acciones críticas de este flujo
  (aprobación/bloqueo de revisión, ejecución de cálculo).

### Hallazgos que resuelve

BL-07, BL-08, y la porción de BL-09 estrictamente necesaria para que este
flujo específico no quede vulnerable. El resto de BL-09 (sistema de rol
completo, permisos por asignación entre múltiples analistas) permanece en
`fases/FASE-02-SEGURIDAD-Y-CUMPLIMIENTO.md`.

### Condiciones de entrada

Ninguna — puede empezar en paralelo con 1A, coordinando cambios sobre los
mismos archivos (`ejecutar-calculo`, `continuar-tras-revision`).

### Archivos o componentes potencialmente afectados

`supabase/functions/ejecutar-calculo/index.ts`,
`supabase/functions/continuar-tras-revision/index.ts`,
`src/App.tsx` (gate mínimo de rol para las rutas `/admin/revisiones*`),
posible `supabase/functions/_shared/auth.ts` nuevo (adelantado de Fase 02
si conviene no duplicar el patrón una tercera vez).

### Cambios de base de datos potenciales

Ajuste de política RLS en `manual_reviews` para impedir auto-aprobación —
aditivo/de reemplazo de política, no destructivo de datos.

### Riesgos

Ver R-06, R-07, R-08 en `plan/MATRIZ-DE-RIESGOS.md`.

### Pruebas obligatorias

- Invocación directa de `ejecutar-calculo`/`continuar-tras-revision` con
  `analysis_id` ajeno y solo la clave `anon` → debe fallar.
- Un cliente sin rol `analyst`/`admin` no puede aprobar/bloquear su
  propia revisión.

### Criterios de aceptación

Las dos funciones quedan protegidas con el mismo patrón que ya usan las
demás Edge Functions; un cliente ya no puede auto-aprobar su revisión.

### Plan de rollback

Cambios de autenticación son aditivos (agregan verificación) — bajo
riesgo de romper el flujo legítimo si siguen el patrón ya probado en las
demás funciones.

### Condiciones de detención

Ninguna específica más allá de las generales de la fase — este bloque es
de alcance acotado y bajo riesgo de bloquearse por decisiones externas.

---

## Evidencias requeridas (toda la fase)

Commits/diffs de cada corrección, resultado de cada caso de regresión
(1B, 1C), pruebas de caracterización (1A), pruebas de acceso cruzado
(1D), y la aprobación documentada del revisor financiero externo en
`plan/REGISTRO-DE-DECISIONES.md`.

## Checklist de cierre (toda la fase)

- [ ] 1A: motor canónico conectado, PDF y narrativa usan
      `calculation_result`, pruebas de caracterización existen.
- [ ] 1B: BL-02 a BL-05, BL-17, ROE/ROA resueltos con prueba de
      regresión pasando sobre el motor canónico.
- [ ] 1C: casos dorados y trazabilidad hasta el PDF implementados y
      aprobados por el revisor financiero externo.
- [ ] 1D: BL-07, BL-08 y el recorte de BL-09 resueltos y probados.
- [ ] `plan/MATRIZ-DE-RIESGOS.md` actualizada (R-01 a R-08, R-13, R-14).
- [ ] Reporte de implementación completado por cada bloque.

## Plantilla del reporte de implementación

Ver plantilla en `fases/FASE-00-CIERRE-DE-AUDITORIA.md` — usar una
instancia separada por bloque (1A, 1B, 1C, 1D).
