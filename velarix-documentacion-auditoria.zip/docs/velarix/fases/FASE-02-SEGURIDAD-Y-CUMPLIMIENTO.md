# Fase 02 — Seguridad y Cumplimiento Mínimo

## Estado

Bloqueada. Depende del cierre de Fase 01 (parcialmente paralelizable, ver
nota en `plan/ROADMAP.md`).

## Objetivo

`Negocio_Velarix_v4.1.md` §18: "Poder recibir información real de forma
responsable."

## Justificación de negocio

§12.1 del negocio: "La seguridad mínima... debe existir **antes** del
primer cliente real. No se dejan para una fase posterior a la
comercialización." Esta auditoría confirmó 2 brechas de autenticación
BLOQUEANTES y la ausencia de control de rol real que rompe el principio
"la IA nunca aprueba por sí sola" (§8.3).

## Condiciones de entrada

- [ ] Fase 01 cerrada, o al menos BL-01 (decisión raíz) resuelta si se
      decide paralelizar parcialmente.
- [ ] Al menos una cuenta `analyst` real distinta del cliente disponible
      para probar BL-09 (dependencia de negocio).

## Alcance

- BL-07 — Verificar ownership en `ejecutar-calculo`.
- BL-08 — Autenticar `continuar-tras-revision`.
- BL-09 — Implementar control de rol real.
- BL-10 — Cerrar `profiles` UPDATE contra auto-escalamiento de `role`.
- BL-11 — Autenticar `update-snapshots` y `enviar-notificacion`.
- BL-12 — Minimizar datos enviados a Anthropic.
- BL-13 — Implementar eliminación real de datos.
- BL-16 — Auditar descargas (condicional a que exista un endpoint
  servidor de descarga, ver Fase 01/BL-01).
- BL-18 — Extraer `_shared/cors.ts` y `_shared/auth.ts` (aprovechando que
  se tocan estos mismos archivos por BL-07/BL-08).
- BL-21 — Race condition en `map-accounts`.

## Exclusiones

No se implementa aquí ninguna pasarela de pago ni automatización
comercial (Fase 5). No se redacta el contrato/NDA completo aquí (es
trabajo legal, no de código) — solo se documenta la dependencia.

## Hallazgos que resuelve

BL-07 a BL-13, BL-16, BL-18, BL-21. Ver `plan/BACKLOG-CLASIFICADO.md`.

## Dependencias

BL-09 depende de una decisión de negocio sobre el modelo de rol exacto
(quién es "analista" en esta etapa). BL-12 y BL-13 dependen de revisión
legal externa (§12.3, §12.4, §23 del negocio). Ver
`plan/MATRIZ-DE-DEPENDENCIAS.md`.

## Orden interno de trabajo

1. BL-18 (extraer `_shared/auth.ts`) primero, para que BL-07 y BL-08 lo
   usen directamente en vez de escribir un noveno patrón manual.
2. BL-07, BL-08 (en paralelo, mismo patrón).
3. BL-10 (rápido, bajo riesgo, mismo dominio que BL-09).
4. BL-09 (control de rol) — el más grande de esta fase, requiere decisión
   de negocio primero.
5. BL-11, BL-21 (independientes, pueden hacerse en cualquier momento).
6. BL-12, BL-13 (dependen de revisión legal — pueden avanzar en paralelo
   mientras se espera esa revisión, pero no cerrarse sin ella).
7. BL-16 (al final, si ya existe un endpoint servidor de descarga tras
   Fase 01).

## Archivos o componentes potencialmente afectados

`supabase/functions/ejecutar-calculo/index.ts`,
`supabase/functions/continuar-tras-revision/index.ts`,
`supabase/functions/update-snapshots/index.ts`,
`supabase/functions/enviar-notificacion/index.ts`,
`supabase/functions/map-accounts/index.ts`, nuevo
`supabase/functions/_shared/auth.ts` y `_shared/cors.ts`,
`src/App.tsx` (rutas), `src/contexts/AuthContext.tsx`, migraciones nuevas
de RLS sobre `profiles` y `manual_reviews`.

## Cambios de base de datos potenciales

- Migración aditiva: política RLS nueva/ajustada en `manual_reviews` para
  reflejar control de rol real.
- Migración aditiva: `WITH CHECK` en política UPDATE de `profiles`, o
  tabla separada para `role` gestionada solo por service role.
- Posible endpoint/función nueva para eliminación real de datos (BL-13),
  sin migración destructiva sobre datos existentes salvo ejecución
  explícita del borrado a solicitud de un cliente real.

## Riesgos

Ver `plan/MATRIZ-DE-RIESGOS.md` R-06 a R-12, R-15.

## Pruebas obligatorias

- Prueba de invocación directa de `ejecutar-calculo`/`continuar-tras-revision`
  con `analysis_id` ajeno y solo la clave `anon` → debe fallar.
- Prueba de que un usuario sin rol `analyst`/`admin` no puede
  aprobar/bloquear revisiones según el modelo de rol decidido.
- Prueba de que un usuario no puede auto-asignarse `role` vía `UPDATE`.
- Prueba de eliminación real: solicitar borrado de un análisis de prueba
  y confirmar que el documento ya no existe en Storage ni en las tablas
  derivadas.

## Casos de regresión

Los mismos escenarios de prueba de arriba, automatizados y repetibles.

## Criterios de aceptación

`Negocio_Velarix_v4.1.md` §18, Fase 2: "revisión técnica y jurídica
mínima aprobada."

## Evidencias requeridas

Resultado de cada prueba de penetración simple (arriba), aprobación
explícita del abogado externo para BL-12/BL-13, y actualización de
`plan/MATRIZ-DE-RIESGOS.md`.

## Plan de rollback

Los cambios de autenticación/autorización son aditivos (agregan
verificación, no quitan funcionalidad legítima) — bajo riesgo de romper
el flujo normal si se implementan siguiendo el mismo patrón ya probado en
las 7-9 funciones que sí lo hacen bien. Cualquier migración de RLS debe
poder revertirse a la política anterior sin pérdida de datos.

## Condiciones de detención

- Si la revisión legal de BL-12/BL-13 no está disponible, se avanza el
  resto de la fase pero no se cierra sin esos dos ítems o sin una
  decisión explícita documentada de diferirlos con justificación.
- Si no existe todavía una cuenta `analyst` real para probar BL-09, se
  implementa el mecanismo técnico pero no se declara "probado" hasta
  tener esa cuenta.

## Checklist de cierre

- [ ] BL-07, BL-08, BL-09, BL-10, BL-11, BL-18, BL-21 resueltos.
- [ ] BL-12, BL-13, BL-16 resueltos o explícitamente diferidos con
      justificación documentada.
- [ ] Revisión legal mínima documentada.
- [ ] `plan/MATRIZ-DE-RIESGOS.md` actualizada.
- [ ] Reporte de implementación completado.

## Plantilla del reporte de implementación

Ver plantilla en `fases/FASE-00-CIERRE-DE-AUDITORIA.md`.
