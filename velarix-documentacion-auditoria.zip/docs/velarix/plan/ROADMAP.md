# Roadmap

Refleja las Fases 0–8 de `Negocio_Velarix_v4.1.md` §18. Sin fechas
inventadas — solo estados y dependencias. Ver `fases/FASE-XX-*.md` para
el detalle ejecutable de cada una.

| Fase | Objetivo | Estado | Depende de |
|---|---|---|---|
| Fase 0 — Revisión del negocio y del estado real | Alinear documento, repositorio y realidad | **en curso** — la auditoría documental (esta carpeta) queda completa con esta entrega; queda pendiente que el fundador la revise y autorice el cierre | — |
| Fase 1 — Exactitud financiera | Impedir resultados incorrectos | pendiente. Decisión de arquitectura ya tomada (`D-06`); dividida en 4 bloques — ver detalle abajo | Cierre de Fase 0 (autorización del fundador) |
| ↳ 1A — Fuente única de verdad | Conectar el motor servidor a PDF/narrativa; pruebas de caracterización | pendiente | Autorización de inicio |
| ↳ 1B — Corrección financiera | Corregir bugs dentro del motor ya canónico | bloqueada | 1A completo |
| ↳ 1C — Casos dorados y trazabilidad | Probar y trazar el resultado ya corregido | bloqueada | 1B completo |
| ↳ 1D — Controles de acceso P0 del flujo | Cerrar 2 huecos de autenticación + recorte de rol | pendiente, **puede avanzar en paralelo a 1A/1B/1C** | Autorización de inicio |
| Fase 2 — Seguridad y cumplimiento mínimo | Poder recibir información real de forma responsable | bloqueada | Fase 1 (parcialmente independiente — ver nota abajo) |
| Fase 3 — Pilotos controlados | Validar metodología, operación, tiempo y experiencia | bloqueada | Fase 1 + Fase 2 completas, revisor financiero externo identificado |
| Fase 4 — Preparación comercial | Poder vender con claridad y control | bloqueada | Fase 3 completa (mínimo 2 pilotos) |
| Fase 5 — Primer cliente pagado | Validar la entrega comercial completa | bloqueada | Fase 4 completa |
| Fase 6 — Repetibilidad | Demostrar que el servicio puede repetirse | bloqueada | Fase 5 completa (proyecto cerrado y documentado) |
| Fase 7 — Automatización selectiva | Automatizar solo tareas ya validadas | bloqueada | Fase 6 (repetición demostrada, no solo deseada) |
| Fase 8 — Escalamiento | Aumentar capacidad sin reducir calidad | bloqueada | Fase 7 |

## Nota sobre paralelismo Fase 1 / Fase 2

Aunque el orden por defecto es secuencial, algunos ítems de Fase 2
(auditoría RLS, redacción de NDA/contrato) no dependen técnicamente de
que la Fase 1 esté cerrada — pueden avanzar en paralelo si el fundador lo
decide explícitamente y lo registra en `REGISTRO-DE-DECISIONES.md`. El
Bloque 1D (dentro de Fase 1) ya adelanta la porción P0 de seguridad que sí
era bloqueante para no paralelizar (el control de acceso de
`ejecutar-calculo`/`continuar-tras-revision`) — con `D-06` ya decidido,
ese trabajo no necesita esperar a que 1A/1B/1C terminen.

## Nota sobre paralelismo interno de Fase 1 (1A–1D)

Ver `fases/FASE-01-EXACTITUD-FINANCIERA.md`, diagrama de dependencias: 1A
→ 1B → 1C es secuencial; 1D corre en paralelo a los tres, coordinando
cambios sobre los archivos que comparte con 1A (`ejecutar-calculo`,
`continuar-tras-revision`).

## Qué NO tiene fecha todavía (y por qué)

Ninguna fase tiene fecha estimada. `Negocio_Velarix_v4.1.md` §21 marca
como hipótesis pendiente la "duración media" y el "volumen mensual
sostenible" — estimar fechas antes de medir horas reales en al menos un
piloto sería inventar un dato no verificable, prohibido por las reglas de
esta auditoría (§4, "No presentes una sospecha como hecho").
