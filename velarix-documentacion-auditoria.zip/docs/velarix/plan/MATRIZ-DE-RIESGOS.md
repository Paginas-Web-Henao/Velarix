# Matriz de Riesgos

Probabilidad e impacto son juicios cualitativos (Alta/Media/Baja) basados
en la evidencia citada, no en medición estadística. Severidad =
combinación de ambos. "Responsable humano" es siempre el fundador en la
etapa actual (operador único, `Negocio_Velarix_v4.1.md` §8.2), salvo donde
se indique un rol distinto ya identificado (revisor financiero, abogado).

> **Nota (2026-07-23)**: la columna "Fase" de esta tabla no se reescribió
> fila por fila tras la decisión `D-06`. Para la asignación exacta a los
> bloques 1A/1B/1C/1D, usar `plan/BACKLOG-CLASIFICADO.md` (ya actualizado)
> como referencia autoritativa — ahí: R-01↔BL-02 (1B), R-02↔BL-03 (1B),
> R-03↔BL-04 (1B), R-04↔BL-01 (1A), R-05↔BL-05 (1B), R-06↔BL-07 (1D),
> R-07↔BL-08 (1D), R-08↔BL-09 (recorte en 1D, resto en Fase 2), R-13↔BL-14
> (1C), R-14↔BL-06 (1A).

| ID | Dominio | Descripción | Evidencia | Probabilidad | Impacto | Severidad | Señal de detección | Mitigación | Fase | Responsable | Estado |
|---|---|---|---|---|---|---|---|---|---|---|---|
| R-01 | Financiero | Subcuentas no se suman (`.find()`), EBITDA/caja/opex mal calculados | `auditoria/04` #1 | Alta (ocurre en cualquier balance con >1 cuenta por rubro) | Crítico | Crítica | Caso de regresión propuesto en `auditoria/04` falla | Reescribir `getAccountValue`/`getVal`/`getValue` para sumar por `canonical_account`+período | Fase 1 | Fundador + revisor financiero | Abierto |
| R-02 | Financiero | Conversión de moneda nunca se aplica (~4080x de error potencial) | `auditoria/04` (C) | Media (depende de que un cliente suba documento en moneda distinta a COP) | Crítico | Crítica | Caso de regresión con Excel en USD | Persistir `moneda_documento`/`factor_escala` desde `parse-document` hasta `build-structured-input` | Fase 1 | Fundador | Abierto |
| R-03 | Financiero | PDF siempre muestra "USD" | `auditoria/04` #2 | Alta (ocurre en todo análisis en COP) | Alto | Crítica | Inspección visual de cualquier PDF en COP | Crear `formatMoneda(valor, moneda)` paramétrica y usarla en todo `pdf-generator.ts` | Fase 1 | Fundador | Abierto |
| R-04 | Financiero / Arquitectura | Split-brain: PDF (cliente) ignora resultado servidor + narrativa IA | `auditoria/04`, `auditoria/02`, `auditoria/08` | Alta (ocurre siempre, es el flujo por defecto) | Crítico | Crítica | Comparar `analyses.calculation_result` vs. resultado del PDF descargado | Decidir motor oficial único; conectar el flujo real a ese motor | Fase 1 | Fundador | Abierto |
| R-05 | Financiero | `ejecutar-calculo` lee campos inexistentes → `totalDebt` siempre 0 | `auditoria/04` (B) | Baja hoy (motor no se usa), Alta si se conecta | Crítico si se activa | Alta (latente) | Caso de regresión con empresa apalancada | Corregir el nombre del campo (`financial_debt_total`) | Fase 1 | Fundador | Abierto |
| R-06 | Seguridad | `ejecutar-calculo` sin verificación de ownership | `auditoria/05` | Media (requiere que alguien conozca/enumere un `analysis_id` ajeno) | Crítico | Bloqueante | Prueba de invocación directa con `analysis_id` ajeno y clave anon | Agregar verificación `analysis.user_id === user.id` igual que las otras 7 funciones | Fase 2 | Fundador | Abierto |
| R-07 | Seguridad | `continuar-tras-revision` sin ninguna autenticación | `auditoria/05` | Media | Crítico | Bloqueante | Igual que R-06 | Agregar el mismo patrón de autenticación que las demás funciones | Fase 2 | Fundador | Abierto |
| R-08 | Seguridad / Negocio | Sin control de rol real; auto-aprobación de revisión manual | `auditoria/05`, `auditoria/07` | Alta (cualquier usuario puede probarlo hoy) | Alto (rompe el modelo de negocio, no solo seguridad técnica) | Bloqueante | Revisar si `profiles.role` se usa en alguna política/ruta | Implementar verificación de rol en frontend + política RLS diferenciada para `manual_reviews` | Fase 2 | Fundador | Abierto |
| R-09 | Seguridad | `profiles` UPDATE sin `WITH CHECK`, riesgo de auto-escalar `role` | `auditoria/05` | Baja hoy (nada depende de `role` todavía) | Alto si se activa | Media (latente) | Intento de `UPDATE profiles SET role='admin'` desde un usuario normal | Agregar `WITH CHECK` que excluya la columna `role`, o mover `role` a una tabla separada gestionada solo por service role | Fase 2 | Fundador | Abierto |
| R-10 | Seguridad | `update-snapshots`/`enviar-notificacion` sin autenticación | `auditoria/05` | Media | Medio (integridad de datos compartidos / spam) | Media | Invocación directa sin JWT de usuario | Agregar autenticación mínima o mover a invocación solo por service role/cron | Fase 2 | Fundador | Abierto |
| R-11 | Privacidad | Documentos completos y nombre de empresa enviados a Anthropic sin anonimizar | `auditoria/05` §5 | Alta (ocurre en cada análisis) | Medio (depende de política de datos de Anthropic, no confirmable desde el repo) | Media | Revisión manual de los prompts enviados | Evaluar minimización de datos antes de enviar (`Negocio_Velarix_v4.1.md` §12.3) | Fase 2 | Fundador + abogado externo | Abierto |
| R-12 | Cumplimiento | Sin eliminación real de datos (solo soft-delete) | `auditoria/05` §8 | Alta | Alto (obligación legal potencial, Ley 1581) | Bloqueante | Solicitud de eliminación de un cliente real que no se puede cumplir | Implementar borrado real de documentos/derivados + `storage.remove()` | Fase 2 | Fundador + abogado externo | Abierto |
| R-13 | Calidad | Cero cobertura de pruebas del motor financiero | `auditoria/04`, `auditoria/06` | Alta (certeza, es un hecho actual) | Crítico (cualquier cambio futuro puede reintroducir bugs sin detectarlo) | Crítica | — (es un estado, no un evento) | Crear casos dorados con datos conocidos + pruebas de regresión | Fase 1 | Fundador + revisor financiero | Abierto |
| R-14 | Confiabilidad | `run-analysis-pipeline` no aborta ante falla de `map-accounts` | `auditoria/06` | Media (depende de que la IA falle en ese paso) | Alto (análisis "completado" con datos mal mapeados, sin aviso) | Alta | Log de `map-accounts` con error pero pipeline continuó | Agregar `return`/abort explícito en ese catch, igual que los otros 4 pasos | Fase 1 | Fundador | Abierto |
| R-15 | Confiabilidad | Race condition en `map-accounts` sin lock propio | `auditoria/06` | Baja (requiere doble invocación casi simultánea) | Medio (filas duplicadas en `account_homologations`) | Media | Filas duplicadas para el mismo `analysis_id`+`canonical_account`+período | Agregar lock propio o constraint de unicidad | Fase 2 | Fundador | Abierto |
| R-16 | Negocio / Confianza | Copy de landing usa "Metodología auditada" sin auditoría externa real todavía | `auditoria/07` | Alta (visible hoy) | Medio (riesgo reputacional, no técnico) | Media | Revisión legal del copy | Ajustar lenguaje antes de cualquier lanzamiento comercial | Fase 4 | Fundador | Abierto |
| R-17 | Rendimiento | Bundle 1.76MB sin code-splitting | `auditoria/09` | Alta (estado actual confirmado) | Bajo (afecta tiempo de carga, no exactitud) | Baja | Medición real de LCP/TTI (pendiente, ver plan de medición) | `React.lazy` en rutas pesadas | Fase 7 | Fundador | Abierto — no prioritario |

## Cómo se usa esta matriz

Cada ítem se cierra únicamente cuando: (a) existe una corrección con
evidencia (commit/PR), (b) existe la prueba de regresión correspondiente
pasando, y (c) — para los ítems que lo requieran según
`Negocio_Velarix_v4.1.md` §9.4 — el revisor financiero o legal externo lo
aprobó. El estado se actualiza aquí, no se borra la fila (mantener
historial).
