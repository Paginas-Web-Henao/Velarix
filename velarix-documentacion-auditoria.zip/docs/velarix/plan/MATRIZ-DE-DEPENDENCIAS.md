# Matriz de Dependencias

Qué tarea/hallazgo depende de qué otra cosa antes de poder empezar. Esto
determina el orden interno de trabajo dentro de cada fase (ver
`fases/FASE-XX-*.md`).

## Decisión raíz — RESUELTA (`D-06`, 2026-07-23)

**Decidir cuál motor de cálculo es el oficial** ya no es una decisión
pendiente. `plan/REGISTRO-DE-DECISIONES.md` D-06 declara el pipeline del
servidor (`ejecutar-calculo` + homologación + narrativa) como canónico.
Lo que antes dependía de "tomar la decisión" ahora depende de
**implementarla**, en el orden 1A → 1B → 1C de
`fases/FASE-01-EXACTITUD-FINANCIERA.md`:

| Tarea | Ahora depende de… | Por qué |
|---|---|---|
| Corrección del bug (B) — `ejecutar-calculo` lee campos inexistentes | Bloque 1A completo | Se corrige en 1B, sobre el motor que 1A ya conectó al flujo real — no antes |
| Conexión de `generate-narrative` al flujo real | — | Ya no depende de una decisión pendiente; es tarea explícita del Bloque 1A |
| Diseño del campo de trazabilidad (`document_id`/`mapping_id`) | Bloques 1A y 1B completos | El esquema de datos debe estabilizarse (motor conectado, bugs corregidos) antes de diseñar qué se traza — tarea del Bloque 1C |
| Corrección de `enviar-notificacion` (lee tabla huérfana `calculation_results`) | Bloque 1A | 1A decide si se retira `calculation_results` (plural) en favor de `analyses.calculation_result`, o se ajusta `enviar-notificacion` a leer la columna correcta |
| Casos dorados del motor financiero | Bloques 1A y 1B completos | Bloque 1C — no tiene sentido crear casos dorados sobre un motor que todavía tiene bugs conocidos sin corregir |

## Dependencias entre bugs financieros (independientes entre sí, se ejecutan en el Bloque 1B una vez cerrado el Bloque 1A)

- R-01 (consolidación de subcuentas) — independiente, puede corregirse en
  paralelo con R-02/R-03.
- R-02 (conversión de moneda) — independiente.
- R-03 (PDF "USD") — depende de que exista el dato de `moneda_analisis`
  correctamente propagado (ya existe hoy en `structured_inputs`, no
  depende de R-02 para corregirse, son bugs distintos en archivos
  distintos).
- R-14 (`run-analysis-pipeline` no aborta ante falla de `map-accounts`) —
  independiente, puede corregirse de inmediato.

## Dependencias de seguridad — Bloque 1D (adelantado desde Fase 2) y resto de Fase 2

- R-06 (`ejecutar-calculo` sin ownership) y R-07 (`continuar-tras-revision`
  sin auth) — **ya no esperan a Fase 2**: quedan en el Bloque 1D de la
  Fase 1, en paralelo a 1A/1B/1C (no dependen de que la decisión raíz se
  implemente, solo de que ya se tomó). Independientes entre sí, mismo
  patrón de corrección (replicar el bloque de autenticación que ya usan
  las otras 7-9 funciones).
- El recorte de R-08 necesario para impedir auto-aprobación de revisión
  también se adelanta al Bloque 1D. El **sistema completo** de control de
  rol (permisos por asignación entre múltiples analistas) permanece en
  Fase 2, y depende de que `Negocio_Velarix_v4.1.md` confirme quién
  exactamente puede ser "analista" además del fundador.
- R-12 (eliminación real de datos) — permanece en Fase 2, depende de una
  decisión legal (§12.4, §23 de `Negocio_Velarix_v4.1.md`, pendiente de
  abogado externo) sobre qué constituye "eliminación completa" bajo la
  ley colombiana aplicable, antes de implementar el mecanismo técnico.

## Dependencias hacia el negocio (no técnicas, bloquean fases completas)

- **Revisor financiero externo** (`Negocio_Velarix_v4.1.md` §9.4) — no es
  una tarea de código. Bloquea el cierre de la Fase 1 (aprobación de
  metodología y casos dorados) y el inicio de la Fase 3 (pilotos).
  Identificar a esta persona es dependencia humana, no técnica, y debe
  resolverse en paralelo al trabajo de código de la Fase 1, no después.
- **Contrato y NDA** (`Negocio_Velarix_v4.1.md` §7, §23) — bloquea el
  inicio de la Fase 3 (no se puede recibir información real de un piloto
  sin esto). Depende de revisión de un abogado externo (§8.2).
- **Precio validado** (`Negocio_Velarix_v4.1.md` §6.2, §6.4) — bloquea la
  Fase 4 (preparación comercial), no bloquea la Fase 1/2/3.

## Qué NO puede empezar todavía (resumen)

| Tarea | Bloqueada por |
|---|---|
| Bloque 1B (corrección de bugs financieros) | Bloque 1A completo (ya no "decisión raíz pendiente" — ahora es una dependencia de secuencia de implementación) |
| Bloque 1C (casos dorados y trazabilidad) | Bloque 1B completo |
| Automatización de cobro (Fase 5) | Precio validado + al menos un cliente pagado |
| Retainers/time entries (Fase 7) | Repetibilidad demostrada (Fase 6) — diferido explícitamente por negocio |
| Cualquier piloto con datos reales de un tercero | Fase 1 completa (1A-1D) y Fase 2 completas + revisor financiero + contrato/NDA |
