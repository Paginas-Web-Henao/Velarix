# Plan Maestro

Este documento ordena el trabajo recomendado **sin implementarlo**. Fuente
de evidencia: `auditoria/*`. Fuente de autoridad de negocio:
`Negocio_Velarix_v4.1.md`.

> **Actualizado 2026-07-23**: la decisión de arquitectura `D-06`
> (`REGISTRO-DE-DECISIONES.md`) ya resolvió cuál motor de cálculo es el
> oficial (el pipeline del servidor). Esto reemplaza el punto 4 de P0 de
> "decidir" a "implementar la decisión ya tomada", y divide la Fase 1 en
> cuatro bloques (1A-1D) — ver `fases/FASE-01-EXACTITUD-FINANCIERA.md`.

## Estado inicial (al cierre de esta auditoría)

- Producto técnicamente funcional en sus partes individuales, con un
  split-brain arquitectónico central: el pipeline server-side con IA
  (parseo→homologación→validación→cálculo→narrativa) no llega al
  entregable que el cliente realmente recibe (PDF recalculado 100% en el
  navegador, sin narrativa).
- 3 bloqueantes de seguridad confirmados (2 de autenticación, 1 de control
  de rol).
- 4 bugs de cálculo financiero confirmados con causa raíz exacta.
- Cero cobertura de pruebas real.
- Ningún dato de cliente real ha entrado al sistema bajo el modelo de
  negocio v4.1 (etapa precomercial, confirmado por `Negocio_Velarix_v4.1.md`
  §1.4).

## Principios (heredados de `Negocio_Velarix_v4.1.md` §0 y §13)

1. Las decisiones comerciales validadas mandan sobre el código.
2. Una hipótesis de negocio no obliga a construir una funcionalidad.
3. Si el código contradice una decisión confirmada, se corrige el código.
4. No se reorganiza el repositorio por estética — solo con justificación
   de problema concreto, riesgo, beneficio, alcance, pruebas y rollback.
5. Se implementa una fase a la vez; no se abre la siguiente sin cerrar la
   anterior (checklist de cierre en cada `fases/FASE-XX-*.md`).
6. Ningún hallazgo se marca resuelto sin una prueba de regresión que lo
   demuestre.

## Prioridades (P0–P3, ver `Negocio_Velarix_v4.1.md` §17/§18 para el marco de fases)

### P0 — puede alterar cifras, exponer datos, destruir información o impedir pilotos

1. Consolidación de subcuentas rota (`.find()` en 3 archivos) — `auditoria/04`, hallazgo #1. → Fase 1B.
2. Conversión de moneda nunca se aplica — `auditoria/04`, hallazgo (C). → Fase 1B.
3. PDF siempre etiqueta "USD" — `auditoria/04`, hallazgo #2. → Fase 1B.
4. ~~Split-brain de motores de cálculo (decidir cuál es el oficial)~~ — **decidido, `D-06`: el servidor es canónico.** Implementación → Fase 1A.
5. `ejecutar-calculo` sin verificación de ownership — `auditoria/05`. → Fase 1D.
6. `continuar-tras-revision` sin ninguna autenticación — `auditoria/05`. → Fase 1D.
7. Sin control de rol real en `/admin/revisiones` — `auditoria/05`, `auditoria/07`. → recorte P0 en Fase 1D (impedir autoaprobación); sistema completo de rol en Fase 2.
8. `ejecutar-calculo` lee campos inexistentes (`total_debt`/`financial_debt`) — `auditoria/04`, hallazgo (B). Ya no es latente: al declararse este motor canónico (D-06), es P0 real. → Fase 1B.

### P1 — necesario antes del primer cliente pagado

- Casos dorados y pruebas de regresión del motor financiero — `auditoria/04`.
- Trazabilidad mínima documento→cifra — `auditoria/04`, `auditoria/11` C-02.
- Auditoría de descargas — `auditoria/05`.
- Procedimiento real de eliminación de datos — `auditoria/05`.
- `run-analysis-pipeline` debe abortar ante falla de `map-accounts` — `auditoria/06`.
- Revisor financiero externo (persona, no código) — `Negocio_Velarix_v4.1.md` §9.4, bloqueante de negocio, no técnico.
- Contrato y NDA (documentos, no código) — `Negocio_Velarix_v4.1.md` §7, §23.

### P2 — necesario para repetibilidad

- `_shared/cors.ts` y `_shared/auth.ts` (reduce riesgo de que un nuevo endpoint repita el bug de `ejecutar-calculo`) — `auditoria/06`, `auditoria/10`.
- Consolidar los datos macro/sectoriales a una única fuente real, y conectar `ejecutar-calculo` a `external_snapshots` — `auditoria/04`, `auditoria/08`.
- Cobertura de notificaciones (`reporte_listo` dead code, gap de auditoría fallida) — `auditoria/08`.
- Tipar contratos de respuesta entre Edge Functions — `auditoria/06`.

### P3 — optimización, automatización o escalamiento

- Code-splitting del bundle (1.76MB) — `auditoria/09`.
- Paralelizar queries de polling — `auditoria/09`.
- Automatizar `update-snapshots`/`check-data-freshness` con cron real — `auditoria/08`.
- Retainers, time entries, pagos automáticos — diferido explícitamente por negocio (`Negocio_Velarix_v4.1.md` §13.3).

**Regla explícita**: un problema visual (P3) no debe desplazar un error
financiero (P0). Ver `Negocio_Velarix_v4.1.md` §9.

## Dependencias (resumen; detalle completo en `MATRIZ-DE-DEPENDENCIAS.md`)

- La decisión raíz (P0-4) ya está tomada (`D-06`). La secuencia real ahora
  es **1A → 1B → 1C**, con **1D en paralelo** (ver
  `fases/FASE-01-EXACTITUD-FINANCIERA.md`): 1A conecta el motor servidor
  al flujo real y crea pruebas de caracterización; 1B corrige los bugs
  financieros (incluido el bug latente P0-8, que deja de ser latente); 1C
  construye casos dorados y trazabilidad sobre el motor ya corregido; 1D
  cierra los 2 huecos de autenticación + el recorte de control de rol
  necesario para no consolidar un flujo vulnerable.
- La trazabilidad mínima (1C) depende de que 1A/1B ya hayan estabilizado
  el esquema de datos que se va a trazar.
- El revisor financiero externo (humano) debe estar identificado
  **antes** de que los casos dorados de 1C se den por aprobados
  (`Negocio_Velarix_v4.1.md` §9.4, §10.4) — no es una tarea de código, es
  una condición de entrada a Fase 3.
- El control de rol **completo** (más allá del recorte P0 de 1D) sigue
  siendo prerequisito de Fase 2 para que la revisión manual cumpla su
  propósito de negocio en todos los escenarios, no solo en el flujo
  tocado por Fase 1.

## Estrategia de pruebas

- Ningún bug financiero se cierra sin un caso de regresión que reproduzca
  el escenario exacto documentado en `auditoria/04-CALIDAD-FINANCIERA.md`
  (cada hallazgo ya incluye un caso propuesto).
- Los casos dorados deben cubrir, como mínimo: consolidación de
  subcuentas, conversión de moneda, formato monetario del PDF, WACC/Hamada
  con y sin deuda, ROE/ROA con datos reales vs. sintéticos.
- Ningún caso dorado se aprueba solo por el fundador — requiere
  aprobación del revisor financiero externo (`Negocio_Velarix_v4.1.md` §9.4).

## Estrategia de migraciones

- Ninguna migración se ejecuta como parte de esta auditoría.
- Cambios de esquema futuros (ej. campos de trazabilidad, tabla
  `retainers` cuando se autorice) deben ser aditivos (nuevas columnas/
  tablas), no destructivos, salvo decisión explícita documentada en
  `REGISTRO-DE-DECISIONES.md` con plan de rollback.
- Con `D-06` ya decidido, `analyses.calculation_result` (columna) queda
  como la fuente real — la tabla huérfana `calculation_results` (plural)
  se evalúa para retiro formal en el Bloque 1A, no se asume su borrado
  sin confirmar primero que nada más la referencia.

## Estrategia de rollback

- Cada `fases/FASE-XX-*.md` debe declarar su propio plan de rollback
  específico antes de ejecutarse (plantilla ya incluida en cada archivo).
- Regla general: ningún cambio en Edge Functions se despliega sin poder
  revertir al `index.ts` anterior (control de versión estándar); ninguna
  migración se aplica sin su reversa correspondiente documentada.

## Reglas de alcance

- No se implementan funcionalidades diferidas por negocio (§13.3) como
  efecto colateral de resolver un bug (ej. no construir un sistema de
  retainers al resolver la trazabilidad).
- No se reorganiza el repositorio (`frontend/`+`backend/` u otra
  estructura) sin justificación explícita — ver `auditoria/10`.

## Criterio para detenerse

Idéntico a `Negocio_Velarix_v4.1.md` §19 "Regla de detención": falta una
decisión crítica, una migración sería destructiva, hay riesgo de pérdida
de datos, el resultado financiero esperado no está definido, una prueba
falla, el código contradice una decisión confirmada, el alcance requiere
otra fase, o existe una duda legal/metodológica que no se puede resolver
con código.

## Punto recomendado para comenzar

**`fases/FASE-01-EXACTITUD-FINANCIERA.md`, Bloque 1A** — con la decisión
raíz ya tomada (`D-06`), el siguiente paso es el inventario comparativo de
ambos motores y las pruebas de caracterización, antes de tocar ningún bug
financiero (1B) o de construir casos dorados (1C) que documentarían un
comportamiento que ya se sabe incorrecto. El Bloque 1D (accesos P0) puede
avanzar en paralelo desde ya, sin esperar a 1A.
