# Definición de Terminado

"Compilar no es suficiente." Criterios globales y por tipo de tarea. Un
hallazgo de esta auditoría no se cierra hasta cumplir el criterio
correspondiente.

## Criterio global (aplica a toda tarea, sin excepción)

- [ ] El cambio tiene una prueba automatizada que falla sin el cambio y
      pasa con él (no basta con probarlo manualmente una vez).
- [ ] `npx tsc --build --noEmit` y `npm run lint` no introducen errores
      nuevos respecto al estado documentado en `auditoria/06`.
- [ ] El cambio está documentado: qué se corrigió, por qué, y con qué
      evidencia (referencia al hallazgo de `auditoria/*` que resuelve).
- [ ] Si el cambio toca un hallazgo `BLOQUEANTE`, se actualiza su estado
      en `plan/MATRIZ-DE-RIESGOS.md`, no se elimina la fila.
- [ ] No se marca "terminado" ocultando un error — si algo queda
      pendiente, se documenta explícitamente como tal, no se omite.

## Código (general)

- [ ] Sin `any` nuevo en contratos de respuesta entre Edge Functions
      (excepción ya identificada como no diferible, ver `auditoria/10`).
- [ ] Sin duplicación nueva de lógica ya identificada como duplicada
      (`corsHeaders`, patrón de auth, constantes macro) — si se toca uno
      de esos archivos, se aprovecha para consolidar, no para añadir una
      quinta copia.

## Bug financiero

- [ ] Existe un caso de regresión con datos conocidos y resultado
      esperado (los propuestos en `auditoria/04-CALIDAD-FINANCIERA.md`
      son el mínimo, no el máximo).
- [ ] El caso de regresión se ejecuta en CI o al menos localmente antes de
      cada cambio futuro al motor de cálculo (no basta con correrlo una
      vez).
- [ ] El revisor financiero externo (`Negocio_Velarix_v4.1.md` §9.4)
      revisó y aprobó el cambio de metodología o fórmula, si aplica —
      un cambio de código en el motor de cálculo sin esta revisión no se
      considera terminado para efectos de la Fase 1.
- [ ] Se comparó el resultado contra un cálculo independiente en Excel
      (§10.2 del negocio) para al menos un caso real o realista.

## Migración de base de datos

- [ ] Es aditiva (nueva columna/tabla), no destructiva, salvo decisión
      explícita en `REGISTRO-DE-DECISIONES.md` con plan de rollback.
- [ ] Tiene su reversa (`down`) documentada o, si Supabase no la requiere
      explícitamente, un procedimiento manual de reversión escrito.
- [ ] No se ejecuta contra producción sin haberse probado antes en un
      entorno no productivo.
- [ ] RLS se revisa explícitamente para cualquier tabla nueva — no se
      asume que "ya heredará" seguridad de otra tabla.

## RLS / seguridad

- [ ] La política se probó con al menos dos usuarios distintos (uno que
      debe poder, uno que no debe poder) — no basta con probar el caso
      feliz.
- [ ] Si la corrección toca `ejecutar-calculo` o `continuar-tras-revision`
      (R-06/R-07), se verifica explícitamente que ya no sea invocable con
      un `analysis_id` ajeno usando solo la clave `anon`.
- [ ] Si la corrección toca control de rol (R-08), se verifica que un
      usuario sin rol `analyst`/`admin` ya no pueda aprobar/bloquear
      revisiones ajenas ni las propias sin la intervención de un tercero,
      según lo que finalmente decida el negocio.

## UI / frontend

- [ ] Estados de carga, error, vacío y éxito están cubiertos
      explícitamente (no solo el camino feliz) — ver brechas ya
      identificadas en `auditoria/07`.
- [ ] Ningún texto nuevo de UI afirma algo no autorizado por
      `Negocio_Velarix_v4.1.md` §2.2 (rigor Big Four, garantías, auditoría
      certificada, "sin intervención humana").
- [ ] Botones interactivos nuevos tienen `aria-label` si son icon-only.

## Integración externa (Anthropic, Resend, pasarela de pago futura)

- [ ] Se documenta explícitamente qué datos se envían al proveedor
      externo y por qué (mínimo necesario, no el documento completo por
      defecto) — según `Negocio_Velarix_v4.1.md` §12.3.
- [ ] Existe manejo explícito de fallo del proveedor (no un `catch` que
      degrade silenciosamente sin dejar rastro en `audit_events`).

## Documentación

- [ ] Todo hallazgo nuevo cita archivo + línea o comando + resultado.
- [ ] No se presenta una hipótesis de negocio como requisito técnico
      confirmado.
- [ ] Los enlaces relativos entre archivos de `docs/velarix/` funcionan.

## Fase completa

- [ ] Se cumplió el "Criterio de salida" declarado en
      `Negocio_Velarix_v4.1.md` §18 para esa fase específica.
- [ ] Se cumplió el checklist de cierre del archivo
      `fases/FASE-XX-*.md` correspondiente.
- [ ] El fundador (u otra persona autorizada) confirmó explícitamente el
      cierre — ninguna fase se autocierra por criterio de una sesión de
      Claude Code.
