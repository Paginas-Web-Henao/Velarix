# Matriz de Trazabilidad

Conecta: Documento original → parsed document → mapping → structured
input → fórmula → calculation result → narrative → PDF. Indica qué
enlaces existen hoy y cuáles faltan (`Negocio_Velarix_v4.1.md` §10.3
exige que cada cifra material sea trazable hasta la persona que aprobó).

| Enlace | ¿Existe hoy? | Evidencia | Falta | Se cierra en |
|---|---|---|---|---|
| Documento original → `documents` | Sí | `upload-document/index.ts` inserta fila con `storage_path`, checksum | — | — |
| `documents` → `documents_parsed` (parsed document) | Sí, por `document_id` | `parse-document/index.ts:628` (`documents_parsed.document_id`) | — | — |
| `documents_parsed` → `account_homologations` (mapping) | Sí, por `document_id` | `map-accounts/index.ts:219,234` guarda `document_id` por fila | — | — |
| `account_homologations` → `structured_inputs` (structured input) | **No** | `build-structured-input` agrega valores vía `getAccountValue` sin guardar de qué fila(s) vino la suma | Campo `source_mapping_ids`/`document_ids` en `structured_inputs.input_payload` o tabla aparte | Bloque 1C |
| `structured_inputs` → fórmula aplicada | **No** | `ejecutar-calculo`/`financial-engine.ts` no registran qué versión de fórmula/constantes se usó | Campo de versión de fórmula (ver `DEFINICION-DE-TERMINADO.md`, criterio "versionado de fórmulas") | Bloque 1C (versionado depende de que 1B ya haya consolidado las constantes, BL-17) |
| Fórmula → `calculation_result` | Parcial | El resultado se guarda (`analyses.calculation_result`), pero no los supuestos intermedios (tasa usada, sector benchmark exacto aplicado) más allá de lo que ya está en el JSON de salida | Confirmar que el payload de salida incluya explícitamente cada supuesto usado, no solo el resultado final | Bloque 1C |
| `calculation_result` → `report_narratives` (narrative) | **No, hoy** | `generate-narrative` no se invoca en el flujo real (ver `auditoria/04`, `auditoria/08`) | Conectar `generate-narrative` a `run-analysis-pipeline` | **Bloque 1A** (decisión ya tomada en `D-06`, tarea explícita de este bloque) |
| `report_narratives`/`calculation_result` → PDF | **No, hoy** | El PDF se genera desde un recálculo independiente en el navegador (`financial-engine.ts`), no desde `calculation_result` ni `report_narratives` | Reconectar `Dashboard.tsx::handleDownloadPDF` a `calculation_result` | **Bloque 1A** — hallazgo central del split-brain, ya resuelto como decisión (`D-06`), pendiente de implementación |
| Cifra del PDF → persona que aprobó | **No** | Ningún flujo de revisión humana se ejecuta sobre el resultado numérico final antes de la descarga (la revisión manual existente opera sobre `account_homologations`, un paso anterior) | Requiere que exista un paso de aprobación posterior al cálculo, antes de habilitar la descarga — condición implícita en `Negocio_Velarix_v4.1.md` §8.3 | Bloque 1A (define el estado de "aprobado para entrega") + Bloque 1D (control de rol que hace la aprobación significativa) |

## Conclusión

La trazabilidad es sólida en los primeros 3 pasos (documento → parseo →
mapping) y se rompe completamente a partir de `structured_inputs`. Esto
significa que hoy, ante la pregunta "¿de qué fila del Excel salió este
EBITDA en el PDF que descargó el cliente?", la única forma de responder es
re-consultar manualmente `account_homologations` por `analysis_id` +
`canonical_account`, sin poder filtrar por el período o el valor
específico que efectivamente se usó — y ni siquiera esa reconstrucción
manual llega hasta el PDF, porque el PDF usa un recálculo independiente.

**Actualizado 2026-07-23**: con `D-06` ya decidido (el servidor es el
motor canónico), esta matriz deja de tener una dependencia abierta — cada
enlace faltante ya tiene un bloque concreto de `fases/FASE-01-EXACTITUD-FINANCIERA.md`
donde se cierra (columna "Se cierra en"). El orden real es 1A primero
(conecta narrativa y PDF al resultado servidor), 1C después (trazabilidad
fina sobre ese resultado ya conectado y corregido por 1B).
